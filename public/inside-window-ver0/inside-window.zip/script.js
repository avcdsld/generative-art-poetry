/*
 * inside window
 * Author: Zeroichi Arakawa
 * License: This project is licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0). See the LICENSE file for more details.
 *
 * This project includes the following external components:
 * - fxhash.min.js: Created by fxhash, provided under the MIT License.
 * - Source Code Pro font: Provided under the SIL Open Font License 1.1.
 *
 * Please refer to the respective license terms of each external component.
 */

const backgroundDiv = document.createElement('div');
backgroundDiv.id = 'background';
const bgColors = [
  'rgba(255, 193, 7, 0.66)', // Amber
  'rgba(13, 71, 161, 0.66)', // Dark Blue
  'rgba(233, 30, 99, 0.66)', // Pink
  'rgba(0, 150, 136, 0.66)', // Teal
  'rgba(255, 87, 34, 0.66)'  // Deep Orange
];
backgroundDiv.style.color = bgColors[Math.floor(random() * bgColors.length)];
document.body.appendChild(backgroundDiv);

const codeBoxDiv = document.createElement('div');
codeBoxDiv.id = 'codeBox';
document.body.appendChild(codeBoxDiv);

async function draw() {
  const target = window;
  const propNames = Object.getOwnPropertyNames(target);
  const funcNames = propNames.filter(name => typeof target[name] === 'function');
  const funcIndex = Math.floor(random() * funcNames.length);
  const functionName = funcNames[funcIndex];

  codeBoxDiv.innerHTML = `<pre>
try {
  window.${functionName}()
} catch (e) {                     
  e.message
}
</pre>`;

  let executedResult = functionName + ' '
  try {
    await target[names[funcIndex]]();
  } catch (e) {
    try {
      executedResult += e.toString() + ' ';
    } catch (err) {
      executedResult += err.toString() + ' ';
    }
  }

  const stepY = 20;
  const fontSize = backgroundDiv.style.fontSize;
  let bgText = '';
  let bgOneLine = '';
  if (textWidth(bgOneLine + executedResult, fontSize) > window.innerWidth) {
    bgOneLine += executedResult;
  } else {
    while (textWidth(bgOneLine, fontSize) < window.innerWidth + window.innerWidth/5) {
      bgOneLine += executedResult;
    }
  }
  const chars = Array.from(bgOneLine);
  const offset = Math.floor(random() * 30);
  for (let y = 0; y - stepY < window.innerHeight; y += stepY) {
    for (let i = 0; i < offset; i++) {
      chars.push(chars.shift());
    }
    bgText += chars.join('') + '\n';
  }
  background.textContent = bgText;

  $fx.preview();
}

function textWidth(text, fontSize) {
  const tempDiv = document.createElement('div');
  tempDiv.style.position = 'absolute';
  tempDiv.style.float = 'left';
  tempDiv.style.whiteSpace = 'nowrap';
  tempDiv.style.visibility = 'hidden';
  tempDiv.style.fontFamily = "'Source Code Pro', monospace";
  tempDiv.style.fontSize = `${fontSize}px`;
  tempDiv.textContent = text;
  document.body.appendChild(tempDiv);
  const width = tempDiv.offsetWidth;
  document.body.removeChild(tempDiv);
  return width;
}

function random() {
  return $fx.rand();
}

window.onload = _event => {
  draw();
};
